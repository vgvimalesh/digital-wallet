import uuid
import random
import string
import json
from datetime import datetime, timedelta

def generate_username():
    length = random.randint(5, 20)
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def generate_mock_data(num_records=100):
    data = []
    now = datetime.utcnow()
    
    for _ in range(num_records):
        username = generate_username()
        created_at = now - timedelta(days=random.randint(1, 365), hours=random.randint(0, 23))
        last_login = created_at + timedelta(days=random.randint(0, (now - created_at).days), 
                                            hours=random.randint(0, 23))
        
        record = {
            "userId": str(uuid.uuid4()),
            "username": username,
            "email": f"{username}@{random.choice(['gmail.com', 'outlook.com', 'yahoo.com', 'example.com'])}",
            "isActive": random.choice([True, False]),
            "createdAt": created_at.isoformat() + "Z",
            "lastLogin": last_login.isoformat() + "Z"
        }
        data.append(record)
    return data

if __name__ == "__main__":
    mock_data = generate_mock_data(100)
    with open('mock_user_profiles.json', 'w') as f:
        json.dump(mock_data, f, indent=4)
    print(f"Successfully generated 100 records in mock_user_profiles.json")
