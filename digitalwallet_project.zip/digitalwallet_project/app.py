import os
import base64
import random
import string
import sys
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import datetime
import io
from reportlab.pdfgen import canvas
from bson.objectid import ObjectId
from twilio.rest import Client
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)
app = Flask(__name__)
app.secret_key = 'super_secret_key_for_hackathon_demo'

# Localization Dictionary
TRANSLATIONS = {
    'en': {
        'dashboard': 'Dashboard',
        'my_profile': 'My Profile',
        'sign_out': 'Sign Out',
        'available_balance': 'Available Balance',
        'transfer_funds': 'Transfer Funds',
        'spending_insight': 'Spending Insight',
        'transaction_activity': 'Transaction Activity',
        'report_issue': 'Report an Issue',
        'admin_center': 'Administrative Center',
        'revenue': 'Network Revenue',
        'global_search': 'Global Intelligence Search',
        'update_profile': 'Modify Profile Attributes',
        'verification_queue': 'Identity Verification Queue',
        'audit_trail': 'System Audit Metadata (Live Trail)',
        'success_sent': 'Successfully sent funds!',
        'success_profile': 'Profile update request submitted.',
        'error_auth': 'Invalid credentials.',
        'reason_placeholder': 'Explain the reason for this update request...',
        'proof_required': 'UPLOADING NEW PROOF OF IDENTITY (Image/PDF)'
    },
    'hi': {
        'dashboard': 'डैशबोर्ड',
        'my_profile': 'मेरी प्रोफाइल',
        'sign_out': 'साइन आउट',
        'available_balance': 'उपलब्ध शेष राशि',
        'transfer_funds': 'धन हस्तांतरण',
        'spending_insight': 'व्यय अंतर्दृष्टि',
        'transaction_activity': 'लेन-देन गतिविधि',
        'report_issue': 'समस्या की रिपोर्ट करें',
        'admin_center': 'प्रशासनिक केंद्र',
        'revenue': 'नेटवर्क राजस्व',
        'global_search': 'वैश्विक इंटेलिजेंस खोज',
        'update_profile': 'प्रोफ़ाइल विशेषताएँ बदलें',
        'verification_queue': 'पहचान सत्यापन कतार',
        'audit_trail': 'सिस्टम ऑडिट मेटाडेटा (लाइव ट्रेल)',
        'success_sent': 'धन सफलतापूर्वक भेजा गया!',
        'success_profile': 'प्रोफ़ाइल अपडेट अनुरोध सबमिट किया गया।',
        'error_auth': 'अवैध क्रेडेंशियल।',
        'reason_placeholder': 'इस अपडेट अनुरोध का कारण बताएं...',
        'proof_required': 'पहचान का नया प्रमाण अपलोड करें (छवि/पीडीएफ)'
    },
    'ta': {
        'dashboard': 'டாஷ்போர்டு',
        'my_profile': 'எனது சுயவிவரம்',
        'sign_out': 'வெளியேறு',
        'available_balance': 'கிடைக்கக்கூடிய இருப்பு',
        'transfer_funds': 'பணப் பரிமாற்றம்',
        'spending_insight': 'செலவு நுண்ணறிவு',
        'transaction_activity': 'பரிவர்த்தனை நடவடிக்கை',
        'report_issue': 'ஒரு சிக்கலைப் புகாரளிக்கவும்',
        'admin_center': 'நிர்வாக மையம்',
        'revenue': 'நெட்வொர்க் வருவாய்',
        'global_search': 'உலகளாவிய நுண்ணறிவு தேடல்',
        'update_profile': 'சுயவிவரப் பண்புகளை மாற்றவும்',
        'verification_queue': 'அடையாள சரிபார்ப்பு வரிசை',
        'audit_trail': 'கணினி தணிக்கை தரவு (நேரடி தடம்)',
        'success_sent': 'பணம் வெற்றிகரமாக அனுப்பப்பட்டது!',
        'success_profile': 'சுயவிவர புதுப்பிப்பு கோரிக்கை சமர்ப்பிக்கப்பட்டது.',
        'error_auth': 'தவறான நற்சான்றிதழ்கள்.',
        'reason_placeholder': 'இந்த புதுப்பிப்பு கோரிக்கைக்கான காரணத்தை விளக்கவும்...',
        'proof_required': 'அடையாளத்தின் புதிய ஆதாரத்தைப் பதிவேற்றவும் (படம்/PDF)'
    },
    'ml': {
        'dashboard': 'ഡാഷ്‌ബോർഡ്',
        'my_profile': 'എന്റെ പ്രൊഫൈൽ',
        'sign_out': 'പുറത്തു കടക്കുക',
        'available_balance': 'ലഭ്യമായ ബാലൻസ്',
        'transfer_funds': 'പണം കൈമാറ്റം',
        'spending_insight': 'ചെലവ് വിശകലനം',
        'transaction_activity': 'ഇടപാടുകൾ',
        'report_issue': 'പരാതി നൽകുക',
        'admin_center': 'അഡ്മിൻ സെന്റർ',
        'revenue': 'നെറ്റ്‌വർക്ക് വരുമാനം',
        'global_search': 'ഗ്ലോബൽ സെർച്ച്',
        'update_profile': 'പ്രൊഫൈൽ മാറ്റുക',
        'verification_queue': 'വെരിഫിക്കേഷൻ ക്യൂ',
        'audit_trail': 'ഓഡിറ്റ് ലോഗുകൾ',
        'success_sent': 'പണം വിജയകരമായി അയച്ചു!',
        'success_profile': 'അപേക്ഷ സമർപ്പിച്ചു.',
        'error_auth': 'തെറ്റായ പാസ്‌വേഡ്.',
        'reason_placeholder': 'കാരണം വ്യക്തമാക്കുക...',
        'proof_required': 'പുതിയ ഐഡി പ്രൂഫ് അപ്‌ലോഡ് ചെയ്യുക (Image/PDF)'
    },
    'kn': {
        'dashboard': 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
        'my_profile': 'ನನ್ನ ಪ್ರೊಫೈಲ್',
        'sign_out': 'ಸೈನ್ ಔಟ್',
        'available_balance': 'ಲಭ್ಯವಿರುವ ಬ್ಯಾಲೆನ್ಸ್',
        'transfer_funds': 'ಹಣ ವರ್ಗಾವಣೆ',
        'spending_insight': 'ಖರ್ಚುಗಳ ಮಾಹಿತಿ',
        'transaction_activity': 'ವಹಿವಾಟಿನ ಚಟುವಟಿಕೆ',
        'report_issue': 'ದೂರು ಸಲ್ಲಿಸಿ',
        'admin_center': 'ಆಡಳಿತ ಕೇಂದ್ರ',
        'revenue': 'ಜಾಲದ ಆದಾಯ',
        'global_search': 'ಜಾಗತಿಕ ಹುಡುಕಾಟ',
        'update_profile': 'ಪ್ರೊಫೈಲ್ ತಿದ್ದುಪಡಿ',
        'verification_queue': 'ಪರಿಶೀಲನಾ ಸರತಿ',
        'audit_trail': 'ಸಿಸ್ಟಮ್ ಆಡಿಟ್',
        'success_sent': 'ಹಣ ಯಶಸ್ವಿಯಾಗಿ ಕಳುಹಿಸಲಾಗಿದೆ!',
        'success_profile': 'ಪ್ರೊಫೈಲ್ ಅಪ್‌ಡೇಟ್ ಸಲ್ಲಿಸಲಾಗಿದೆ.',
        'error_auth': 'ತಪ್ಪಾದ ಪ್ರವೇಶ ವಿವರಗಳು.',
        'reason_placeholder': 'ಕಾರಣವನ್ನು ತಿಳಿಸಿ...',
        'proof_required': 'ಹೊಸ ಗುರುತಿನ ಚೀಟಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ (Image/PDF)'
    }
}

@app.context_processor
def inject_translate():
    def translate_helper(key):
        lang = session.get('lang', 'en')
        return TRANSLATIONS.get(lang, TRANSLATIONS['en']).get(key, key)
    
    # Global User Metadata for Navbar
    user_status = None
    profile_photo = None
    if 'user_id' in session:
        user = users_col.find_one({"_id": ObjectId(session['user_id'])})
        if user:
            user_status = user.get('status')
            profile_photo = user.get('profile_photo')
            
    return dict(_=translate_helper, user_status=user_status, profile_photo=profile_photo)

@app.route('/set_lang/<lang>')
def set_lang(lang):
    if lang in TRANSLATIONS:
        session['lang'] = lang
    return redirect(request.referrer or url_for('index'))

# --- Security & Session Management ---
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,   # Prevent JavaScript from accessing cookies (XSS Protection)
    SESSION_COOKIE_SAMESITE='Lax',  # CSRF Protection
    PERMANENT_SESSION_LIFETIME=datetime.timedelta(minutes=30),
    SESSION_COOKIE_SECURE=False     # Set to True if using HTTPS
)

# Role-Based Access Control (RBAC) Permission Registry (For Auditing)
ROLE_PERMISSIONS = {
    "user": ["Transfer Funds", "View Statement", "Raise Support Ticket"],
    "admin": ["Approve/Reject KYC", "Block Users", "Manage Tickets", "View Audit Logs"],
    "superadmin": ["Manage Admin Accounts", "Update System Fees", "Global Audit", "Access Analytics"]
}

# Twilio Configuration (Replace with your own)
TWILIO_ACCOUNT_SID = 'ACeee54ea51ce10cafa040d6a3c9ffe367'
TWILIO_AUTH_TOKEN = '753ea3abab9dc2287f2ae2e7732124a7'
TWILIO_PHONE_NUMBER = '+16415416298' # Note: Ensure this is your actual Twilio trial number.

def send_sms(to_number, otp):
    """Sends SMS via Twilio. Falls back to console log if keys are default."""
    body = f"Your Hawk Vision OTP is: {otp}. Do not share it with anyone."
    
    # Ensure number is in E.164 format (e.g., +91...)
    to_number = str(to_number).strip().replace(' ', '').replace('-', '')
    if not to_number.startswith('+'):
        if len(to_number) == 10:
            to_number = '+91' + to_number
        else:
            to_number = '+' + to_number
    
    # ALWAYS print to terminal for debugging
    print(f"\n[OTP DEBUG] OTP: {otp} | To: {to_number}\n")
    sys.stdout.flush()

    # Check if user has updated the default placeholders
    if TWILIO_ACCOUNT_SID.startswith('ACxxx'):
        print(f"[SMS GATEWAY SIMULATOR] (Twilio Not Configured) Sending OTP {otp} to {to_number}")
        sys.stdout.flush()
        return False
        
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        client.messages.create(
            body=body,
            from_=TWILIO_PHONE_NUMBER,
            to=to_number
        )
        print(f"[TWILIO SUCCESS] SMS Sent successfully to {to_number}")
        sys.stdout.flush()
        return True
    except Exception as e:
        print(f"[TWILIO ERROR] Failed to send SMS: {e}")
        sys.stdout.flush()
        return False

# MongoDB Configuration
MONGO_URI = "mongodb+srv://Manju:Maura@cluster0.m6eal.mongodb.net/digitalwallet?retryWrites=true&w=majority&appName=Cluster0"

try:
    # Try connecting to the provided URI (Cloud Atlas)
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    client.server_info() # Check if connection is actually working
    db = client['digitalwallet']
    print("Successfully connected to REAL MongoDB (Cloud Atlas).")
    sys.stdout.flush()
except Exception as e:
    import mongomock
    client = mongomock.MongoClient()
    db = client['digitalwallet']
    print(f"Warning: Real MongoDB failed ({e}). Using MONGOMOCK (In-memory). Data will reset on restart.")
    sys.stdout.flush()

users_col = db['users']
transactions_col = db['transactions']
tickets_col = db['tickets']
audit_logs = db['audit_logs']
system_config = db['system_config']
profile_requests_col = db['profile_requests']

PROOFS_UPLOAD_FOLDER = os.path.join(app.root_path, 'uploads', 'profile_proofs')
PHOTOS_UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'profile_photos') # Publicly accessible for avatars
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

if not os.path.exists(PROOFS_UPLOAD_FOLDER):
    os.makedirs(PROOFS_UPLOAD_FOLDER)
if not os.path.exists(PHOTOS_UPLOAD_FOLDER):
    os.makedirs(PHOTOS_UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Ensure Default System Config
if not system_config.find_one({"key": "transaction_fee"}):
    system_config.insert_one({"key": "transaction_fee", "value": 0.02}) # 2% Default Fee

def log_action(action, target, details=""):
    """Helper to record administrative actions."""
    audit_logs.insert_one({
        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "actor": session.get('username', 'system'),
        "action": action,
        "target": target,
        "details": details
    })

# Ensure Super Admin exists at startup
if not users_col.find_one({"username": "superadmin"}):
    users_col.insert_one({
        "username": "superadmin", "password": generate_password_hash("superadmin"),
        "name": "Super Admin", "role": "superadmin", "status": "active", 
        "acc_no": "0000000001", "phone": "9092663335" # Your phone for OTP
    })
    print("Super admin ensured on startup: superadmin / superadmin")

AES_KEY = b'16bytesecretkey!' 

def encrypt_data(data_str):
    cipher = AES.new(AES_KEY, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data_str.encode('utf-8'), AES.block_size))
    iv = base64.b64encode(cipher.iv).decode('utf-8')
    ct = base64.b64encode(ct_bytes).decode('utf-8')
    return f"{iv}:{ct}"

def decrypt_data(encrypted_data):
    try:
        iv, ct = encrypted_data.split(':')
        iv = base64.b64decode(iv)
        ct = base64.b64decode(ct)
        cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
        pt = unpad(cipher.decrypt(ct), AES.block_size).decode('utf-8')
        return pt
    except: return "Decryption Error"

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if not session.get('otp_verified'):
            return redirect(url_for('verify_otp'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if session.get('role') not in roles:
                flash("Unauthorized access.", "danger")
                return redirect(url_for('dashboard'))
            # Innovation: Company Network Simulation
            if session.get('role') in ['admin', 'superadmin']:
                remote_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
                is_company_network = any(ip in (remote_ip or '') for ip in ['127.0.0.1', '::1', 'localhost'])
                if not is_company_network:
                    flash(f"Admin panels only accessible via Company Network (Detected: {remote_ip}).", "danger")
                    return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# --- Routes ---

@app.route('/api/stats/revenue')
@login_required
@role_required(['superadmin'])
def get_revenue_stats():
    # Sum of fees per day for last 7 days
    pipeline = [
        {"$group": {
            "_id": {"$substr": ["$date", 0, 10]},
            "total_revenue": {"$sum": "$fee"}
        }},
        {"$sort": {"_id": 1}},
        {"$limit": 7}
    ]
    stats = list(transactions_col.aggregate(pipeline))
    labels = [s['_id'] for s in stats]
    revenue = [s['total_revenue'] for s in stats]
    return {"labels": labels, "revenue": revenue}

@app.route('/api/stats/spending')
@login_required
def get_spending_stats():
    user = users_col.find_one({"_id": ObjectId(session['user_id'])})
    # Spending by category for current user (sent transactions only)
    pipeline = [
        {"$match": {"from_acc": user['acc_no']}},
        {"$group": {
            "_id": "$category",
            "total": {"$sum": "$amount"}
        }}
    ]
    stats = list(transactions_col.aggregate(pipeline))
    labels = [s['_id'] if s['_id'] else 'General' for s in stats]
    data = [s['total'] for s in stats]
    return {"labels": labels, "data": data}

@app.route('/admin/search')
@login_required
@role_required(['admin', 'superadmin'])
def admin_search():
    query = request.args.get('q', '').strip()
    if not query:
        return {"users": [], "transactions": []}
    
    # Simple regex search across multiple fields
    user_results = list(users_col.find({
        "$or": [
            {"username": {"$regex": query, "$options": "i"}},
            {"name": {"$regex": query, "$options": "i"}},
            {"phone": {"$regex": query, "$options": "i"}},
            {"acc_no": {"$regex": query, "$options": "i"}}
        ]
    }, {"password": 0}).limit(10))
    
    # Convert ObjectIds for JSON
    for u in user_results:
        u['_id'] = str(u['_id'])
        
    tx_results = list(transactions_col.find({
        "$or": [
            {"from_acc": query},
            {"to_acc": query},
            {"from_user": {"$regex": query, "$options": "i"}},
            {"to_user": {"$regex": query, "$options": "i"}}
        ]
    }).sort("_id", -1).limit(10))
    
    for tx in tx_results:
        tx['_id'] = str(tx['_id'])
        
    return {"users": user_results, "transactions": tx_results}

@app.route('/api/stats/transactions')
@login_required
@role_required(['superadmin'])
def get_transaction_stats():
    # Get last 7 days of transactions
    pipeline = [
        {"$group": {
            "_id": {"$substr": ["$date", 0, 10]}, # Group by YYYY-MM-DD
            "count": {"$sum": 1},
            "total_volume": {"$sum": "$amount"}
        }},
        {"$sort": {"_id": 1}},
        {"$limit": 7}
    ]
    stats = list(transactions_col.aggregate(pipeline))
    labels = [s['_id'] for s in stats]
    counts = [s['count'] for s in stats]
    volumes = [s['total_volume'] for s in stats]
    
    return {"labels": labels, "counts": counts, "volumes": volumes}

@app.route('/api/lookup_account/<acc_no>')
@login_required
def lookup_account(acc_no):
    """Limited public metadata for recipient verification."""
    user = users_col.find_one({"acc_no": acc_no, "status": "active"}, {"name": 1, "profile_photo": 1, "_id": 0})
    if user:
        return user
    return {"error": "Identity not found"}, 404

@app.route('/ping')
def ping():
    return "alive"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if users_col.find_one({"username": username}):
            flash("Username exists.", "danger")
            return redirect(url_for('signup'))
            
        # Passport Photo Handling
        if 'profile_photo' not in request.files:
            flash("Passport Size Photo is required.", "danger")
            return redirect(url_for('signup'))
        
        photo = request.files['profile_photo']
        if photo.filename == '' or not allowed_file(photo.filename):
            flash("Invalid photo format. Allowed: PNG, JPG", "danger")
            return redirect(url_for('signup'))
            
        photo_filename = secure_filename(photo.filename)
        unique_photo_name = f"{uuid.uuid4().hex}_{photo_filename}"
        photo.save(os.path.join(PHOTOS_UPLOAD_FOLDER, unique_photo_name))

        acc_no = ''.join(random.choices(string.digits, k=10))
        user_data = {
            "username": username,
            "password": generate_password_hash(password),
            "name": request.form['name'],
            "phone": request.form['phone'],
            "email": request.form['email'],
            "pan_card": encrypt_data(request.form['pan_card']),
            "profile_photo": unique_photo_name,
            "acc_no": acc_no,
            "role": "user",
            "balance": 100.0, # Initial bonus
            "status": "pending"
        }
        users_col.insert_one(user_data)
        log_action("Register", username, "New account registration.")
        
        # Generate and Simulate OTP
        otp = ''.join(random.choices(string.digits, k=6))
        session['otp'] = otp
        session['temp_user'] = username
        
        send_sms(user_data['phone'], otp)
        
        flash("Signup successful! Please verify OTP (Sent to your mobile).", "info")
        return redirect(url_for('verify_otp'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        user = users_col.find_one({"username": username})
        if user and check_password_hash(user['password'], request.form['password']):
            if user['status'] == 'blocked':
                flash("Account blocked.", "danger")
                return redirect(url_for('login'))
            
            # Generate and Simulate OTP
            otp = ''.join(random.choices(string.digits, k=6))
            session['otp'] = otp
            session['temp_user'] = username
            
            log_action("LoginInitiate", username, "User started login flow.")
            send_sms(user.get('phone', ''), otp)
            
            return redirect(url_for('verify_otp'))
        flash(_('error_auth'), "danger")
    return render_template('login.html')

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    if 'temp_user' not in session or 'otp' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        entered_otp = request.form['otp']
        if entered_otp == session.get('otp'): 
            user = users_col.find_one({"username": session['temp_user']})
            # Clear sensitive temp data but keep user info
            otp_val = session.get('otp')
            temp_user = session.get('temp_user')
            session.clear()
            
            session['user_id'] = str(user['_id'])
            session['username'] = user['username']
            session['role'] = user['role']
            session['name'] = user['name']
            session['otp_verified'] = True
            return redirect(url_for('dashboard'))
        flash(f"Invalid OTP. Check your logs/terminal.", "danger")
    return render_template('otp.html')

@app.route('/resend-otp')
def resend_otp():
    if 'temp_user' not in session:
        return redirect(url_for('login'))
        
    user = users_col.find_one({"username": session['temp_user']})
    if not user:
        return redirect(url_for('login'))
        
    # Generate new OTP
    otp = ''.join(random.choices(string.digits, k=6))
    session['otp'] = otp
    
    # Send via Twilio
    phone = user.get('phone', '')
    send_sms(phone, otp)
    
    flash("A new OTP has been sent to your mobile.", "info")
    return redirect(url_for('verify_otp'))

@app.route('/dashboard')
@login_required
def dashboard():
    user = users_col.find_one({"_id": ObjectId(session['user_id'])})
    if not user:
        session.clear()
        flash("User session expired. Please log in again.", "warning")
        return redirect(url_for('login'))
        
    if session['role'] == 'user':
        txs = list(transactions_col.find({"$or": [{"from_acc": user['acc_no']}, {"to_acc": user['acc_no']}]}).sort("_id", -1))
        return render_template('dashboard_user.html', user=user, transactions=txs)
    elif session['role'] == 'admin':
        pending = list(users_col.find({"status": "pending"}))
        active = list(users_col.find({"status": "active", "role": "user"}))
        return render_template('dashboard_admin.html', pending_users=pending, active_users=active, tickets=list(tickets_col.find()))
    
    # Superadmin - Transaction Fee & Audit Logs
    fee_setting = system_config.find_one({"key": "transaction_fee"})
    current_fee = fee_setting['value'] if fee_setting else 0.02
    
    admins = list(users_col.find({"role": "admin"}))
    pending = list(users_col.find({"status": "pending"}))
    profile_reqs = list(profile_requests_col.find({"status": "pending"}))
    logs = list(audit_logs.find().sort("_id", -1).limit(50))
    return render_template('dashboard_superadmin.html', 
                           transactions=list(transactions_col.find()), 
                           admins=admins, 
                           pending_users=pending,
                           profile_requests=profile_reqs,
                           logs=logs, 
                           current_fee=current_fee,
                           permissions=ROLE_PERMISSIONS) # Audit data

@app.route('/superadmin/create_admin', methods=['POST'])
@login_required
@role_required(['superadmin'])
def create_admin():
    username = request.form['username']
    password = request.form['password']
    name = request.form['name']
    
    if users_col.find_one({"username": username}):
        flash("Admin username already exists.", "danger")
        return redirect(url_for('dashboard'))
        
    admin_data = {
        "username": username,
        "password": generate_password_hash(password),
        "name": name,
        "role": "admin",
        "status": "active",
        "acc_no": "99" + ''.join(random.choices(string.digits, k=8))
    }
    users_col.insert_one(admin_data)
    log_action("PrivilegeChange", username, "New Admin account created by SuperAdmin.")
    flash(f"Admin account created for {name}!", "success")
    return redirect(url_for('dashboard'))

@app.route('/superadmin/revoke_admin/<admin_id>', methods=['POST'])
@login_required
@role_required(['superadmin'])
def revoke_admin(admin_id):
    users_col.delete_one({"_id": ObjectId(admin_id), "role": "admin"})
    flash("Admin access revoked.", "warning")
    return redirect(url_for('dashboard'))

@app.route('/transfer', methods=['POST'])
@login_required
@role_required(['user'])
def transfer():
    to_acc = request.form['to_acc'].strip()
    amount = float(request.form['amount'])
    sender_password = request.form['password']
    category = request.form.get('category', 'General')
    sender = users_col.find_one({"_id": ObjectId(session['user_id'])})
    
    # 1. Validation: Self-Transfer
    if sender['acc_no'] == to_acc:
        flash("You cannot transfer money to your own account.", "warning")
        return redirect(url_for('dashboard'))
    
    # 2. Validation: Password
    if not check_password_hash(sender['password'], sender_password):
        flash("Invalid transaction password.", "danger")
        return redirect(url_for('dashboard'))
    
    # 3. Validation: Recipient Exists
    receiver = users_col.find_one({"acc_no": to_acc, "status": "active"})
    if not receiver:
        flash("Recipient account not found or is not active.", "danger")
        return redirect(url_for('dashboard'))
    
    # 4. Calculation: Fee & Total
    fee_setting = system_config.find_one({"key": "transaction_fee"})
    current_fee_pct = fee_setting.get('value', 0.02) if fee_setting else 0.02
    fee_val = amount * current_fee_pct
    total_deduct = amount + fee_val
    
    # 5. Validation: Funds
    if sender['balance'] < total_deduct:
        flash(f"Insufficient funds. Required: ₹{total_deduct:.2f} (Amount: ₹{amount} + Fee: ₹{fee_val:.2f})", "danger")
        return redirect(url_for('dashboard'))
    
    # 6. Execution: Atomic Update (Simulation)
    try:
        # Deduct from Sender
        users_col.update_one({"acc_no": sender['acc_no']}, {"$inc": {"balance": -total_deduct}})
        # Add to Receiver
        users_col.update_one({"acc_no": to_acc}, {"$inc": {"balance": amount}})
        
        # Record Transaction
        transactions_col.insert_one({
            "from_acc": sender['acc_no'],
            "from_user": sender['username'],
            "to_acc": to_acc,
            "to_user": receiver['username'],
            "amount": amount,
            "fee": fee_val,
            "category": category,
            "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        # Audit Log
        log_action("Transfer", sender['username'], f"Sent ₹{amount} to {receiver['username']} (Fee: ₹{fee_val:.2f})")
        
        flash(_('success_sent'), "success")
    except Exception as e:
        flash(f"Transaction failed: {str(e)}", "danger")
        
    return redirect(url_for('dashboard'))

@app.route('/statement')
@login_required
@role_required(['user'])
def download_statement():
    user = users_col.find_one({"_id": ObjectId(session['user_id'])})
    txs = list(transactions_col.find({"$or": [{"from_acc": user['acc_no']}, {"to_acc": user['acc_no']}]}).sort("_id", -1))
    
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)
    p.drawString(100, 800, f"Statement for {session['name']} (A/C: {user['acc_no']})")
    
    y = 750
    for tx in txs:
        date = tx['date']
        if tx['from_acc'] == user['acc_no']:
            desc = f"Sent ₹{tx['amount']} to A/C {tx['to_acc']}"
        else:
            desc = f"Received ₹{tx['amount']} from A/C {tx['from_acc']}"
        p.drawString(100, y, f"{date} | {desc}")
        y -= 20
        if y < 50:
            p.showPage()
            y = 800
            
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name='statement.pdf', mimetype='application/pdf')

@app.route('/raise_ticket', methods=['POST'])
@login_required
@role_required(['user'])
def raise_ticket():
    subject = request.form['subject']
    description = request.form['description']
    
    ticket = {
        "user": session['username'],
        "subject": subject,
        "description": description,
        "status": "open",
        "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    tickets_col.insert_one(ticket)
    flash("Support ticket raised.", "success")
    return redirect(url_for('dashboard'))

@app.route('/admin/approve_user/<user_id>', methods=['POST'])
@login_required
@role_required(['admin', 'superadmin'])
def approve_user(user_id):
    user = users_col.find_one({"_id": ObjectId(user_id)})
    users_col.update_one({"_id": ObjectId(user_id)}, {"$set": {"status": "active"}})
    log_action("Approve", user['username'], f"User approved (A/C: {user['acc_no']})")
    flash(f"User {user['username']} approved.", "success")
    return redirect(url_for('dashboard'))

@app.route('/admin/reject_user/<user_id>', methods=['POST'])
@login_required
@role_required(['admin', 'superadmin'])
def reject_user(user_id):
    user = users_col.find_one({"_id": ObjectId(user_id)})
    users_col.update_one({"_id": ObjectId(user_id)}, {"$set": {"status": "rejected", "pan_card": "DELETED"}})
    log_action("Reject", user['username'], f"Verification failed. Decrypted PAN was: {decrypt_data(user['pan_card'])}")
    flash(f"User {user['username']} rejected.", "danger")
    return redirect(url_for('dashboard'))

@app.route('/admin/block_user/<user_id>', methods=['POST'])
@login_required
@role_required(['admin', 'superadmin'])
def block_user(user_id):
    user = users_col.find_one({"_id": ObjectId(user_id)})
    users_col.update_one({"_id": ObjectId(user_id)}, {"$set": {"status": "blocked"}})
    log_action("Block", user['username'], "User blocked due to suspicious activity.")
    flash(f"User {user['username']} blocked.", "warning")
    return redirect(url_for('dashboard'))

@app.route('/admin/decrypt_pan/<user_id>')
@login_required
@role_required(['admin', 'superadmin'])
def decrypt_pan(user_id):
    user = users_col.find_one({"_id": ObjectId(user_id)})
    if user:
        return {"pan": decrypt_data(user['pan_card'])}
    return {"error": "User not found"}, 404

@app.route('/superadmin/update_settings', methods=['POST'])
@login_required
@role_required(['superadmin'])
def update_settings():
    fee = float(request.form['transaction_fee'])
    system_config.update_one({"key": "transaction_fee"}, {"$set": {"value": fee}})
    log_action("SystemConfig", "TransactionFee", f"Fee updated to {fee*100}%")
    flash(f"Transaction fee updated to {fee*100}%.", "success")
    return redirect(url_for('dashboard'))

@app.cli.command("create-superadmin")
def create_superadmin():
    if not users_col.find_one({"username": "superadmin"}):
        users_col.insert_one({
            "username": "superadmin", "password": generate_password_hash("superadmin"),
            "name": "Super Admin", "role": "superadmin", "status": "active", 
            "acc_no": "0000000001", "phone": "9092663335"
        })
        print("Super admin created: superadmin / superadmin")

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = users_col.find_one({"_id": ObjectId(session['user_id'])})
    pending_request = profile_requests_col.find_one({"user_id": session['user_id'], "status": "pending"})
    
    if request.method == 'POST':
        if pending_request:
            flash("You already have a pending profile update request.", "warning")
            return redirect(url_for('profile'))
            
        # File Handling
        if 'proof_file' not in request.files:
            flash("Proof of Identity file is required.", "danger")
            return redirect(url_for('profile'))
            
        file = request.files['proof_file']
        if file.filename == '' or not allowed_file(file.filename):
            flash("Invalid file format. Allowed: PNG, JPG, PDF", "danger")
            return redirect(url_for('profile'))
            
        # Secure Filename with UUID
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        file.save(os.path.join(PROOFS_UPLOAD_FOLDER, unique_filename))
            
        new_data = {
            "user_id": session['user_id'],
            "username": user['username'],
            "name": request.form['name'],
            "email": request.form['email'],
            "phone": request.form['phone'],
            "notes": request.form['notes'],
            "proof_filename": unique_filename,
            "status": "pending",
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        profile_requests_col.insert_one(new_data)
        flash(_('success_profile'), "info")
        return redirect(url_for('profile'))
        
    return render_template('profile.html', user=user, pending_request=pending_request)

@app.route('/admin/view_proof/<filename>')
@login_required
@role_required(['admin', 'superadmin'])
def view_proof(filename):
    return send_file(os.path.join(PROOFS_UPLOAD_FOLDER, filename))

@app.route('/admin/approve_profile/<req_id>', methods=['POST'])
@login_required
@role_required(['admin', 'superadmin'])
def approve_profile(req_id):
    req = profile_requests_col.find_one({"_id": ObjectId(req_id)})
    if req:
        users_col.update_one(
            {"_id": ObjectId(req['user_id'])},
            {"$set": {
                "name": req['name'],
                "email": req['email'],
                "phone": req['phone'],
                "pan_card": req['new_proof']
            }}
        )
        profile_requests_col.update_one({"_id": ObjectId(req_id)}, {"$set": {"status": "approved"}})
        log_action("ProfileApprove", req['username'], f"Profile update approved (New Name: {req['name']})")
        flash(f"Profile update for {req['username']} approved.", "success")
    return redirect(url_for('dashboard'))

@app.route('/admin/reject_profile/<req_id>', methods=['POST'])
@login_required
@role_required(['admin', 'superadmin'])
def reject_profile(req_id):
    req = profile_requests_col.find_one({"_id": ObjectId(req_id)})
    if req:
        profile_requests_col.update_one({"_id": ObjectId(req_id)}, {"$set": {"status": "rejected"}})
        log_action("ProfileReject", req['username'], "Profile update request rejected.")
        flash(f"Profile update for {req['username']} rejected.", "danger")
    return redirect(url_for('dashboard'))

@app.route('/admin/decrypt_profile_proof/<req_id>')
@login_required
@role_required(['admin', 'superadmin'])
def decrypt_profile_proof(req_id):
    req = profile_requests_col.find_one({"_id": ObjectId(req_id)})
    if req:
        # Compatibility check for older text-based proofs
        if 'new_proof' in req:
            return {"proof": decrypt_data(req['new_proof'])}
        return {"filename": req.get('proof_filename')}
    return {"error": "Request not found"}, 404

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
