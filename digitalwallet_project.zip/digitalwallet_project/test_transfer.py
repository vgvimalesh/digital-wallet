import os
from pymongo import MongoClient

# Use the same URI as in the app
MONGO_URI = "mongodb+srv://Manju:Maura@cluster0.m6eal.mongodb.net/digitalwallet?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(MONGO_URI)
db = client['digitalwallet']

def test_transfer():
    # 1. Force Activate all users
    result = db.users.update_many({"role": "user"}, {"$set": {"status": "active"}})
    print(f"Set {result.modified_count} users to active status.")

    # 2. Pick two users
    u1 = db.users.find_one({"username": "test1"})
    u2 = db.users.find_one({"username": "test2"})

    if not u1 or not u2:
        print("Users 'test1' or 'test2' not found. Creating them for testing...")
        # Create as fallback
        db.users.update_one({"username": "test1"}, {"$set": {"acc_no": "1000000001", "balance": 100.0, "status": "active", "role": "user"}}, upsert=True)
        db.users.update_one({"username": "test2"}, {"$set": {"acc_no": "1000000002", "balance": 100.0, "status": "active", "role": "user"}}, upsert=True)
        u1 = db.users.find_one({"username": "test1"})
        u2 = db.users.find_one({"username": "test2"})

    print(f"Sender: {u1['username']} (Balance: INR {u1['balance']})")
    print(f"Receiver: {u2['username']} (Balance: INR {u2['balance']})")

    # 3. Simulate Transfer of INR 15
    amount = 15.0
    fee = amount * 0.02
    total = amount + fee

    if u1['balance'] >= total:
        db.users.update_one({"_id": u1["_id"]}, {"$inc": {"balance": -total}})
        db.users.update_one({"_id": u2["_id"]}, {"$inc": {"balance": amount}})
        
        # Record Transaction
        db.transactions.insert_one({
            "from_acc": u1['acc_no'],
            "from_user": u1['username'],
            "to_acc": u2['acc_no'],
            "to_user": u2['username'],
            "amount": amount,
            "fee": fee,
            "date": "2026-04-05 02:20:00"
        })
        print(f"Successfully transferred INR {amount} (Total including fee: INR {total})")
        
        # Re-fetch
        u1_new = db.users.find_one({"_id": u1["_id"]})
        u2_new = db.users.find_one({"_id": u2["_id"]})
        print(f"New Balances: {u1_new['username']} = INR {u1_new['balance']} | {u2_new['username']} = INR {u2_new['balance']}")
    else:
        print("Insufficient balance for test.")

if __name__ == "__main__":
    test_transfer()
